$(document).ready(function() {
    $('nav a').click(function(e) {
        var href = $(this).attr('href');
        var strip = href.slice(1);
        var target = $('div[id=' + strip + ']');

        $('html, body').animate({
            scrollTop: target.offset().top
        }, 1000);

        e.preventDefault();
    });
});
